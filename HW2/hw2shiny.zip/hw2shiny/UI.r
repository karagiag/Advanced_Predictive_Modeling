# Author: Md Shamsuzzoha Bayzid
# Fall 2016

library(shiny)

# Using 'WorldPhones' dataset from the "datasets" package
library(datasets)

# Define the overall UI
shinyUI(
  
  # Use a fluid Bootstrap layout
  fluidPage(    
    
    # Give the page a title
    titlePanel("Number of telephones by region and year"),
    
    # Generate a sidebar
    sidebarLayout(      
      
        sidebarPanel(
            # select the variable (region or year)
            checkboxGroupInput("feature", "Variables to show:",
                     c("Region" = "region",
                     "Year" = "year"),
			     selected = "region"),
            
        selectInput("region", "Region:", 
                    choices=colnames(WorldPhones)),
        hr(),
       
        selectInput("year", "Year:", 
                    choices=rownames(WorldPhones)),
        hr(),
        helpText("Data from AT&T (1961) The World's Telephones.")
      ),
      
      # Create a spot for the barplot
      mainPanel(
        plotOutput("phonePlot")  
      )
      
    )
  )
)
