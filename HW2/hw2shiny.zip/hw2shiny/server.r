# Author: Md Shamsuzzoha Bayzid
# Fall 2016

library(shiny)

# Using 'WorldPhones' dataset from the "datasets" package

library(datasets)

# Define a server for the Shiny app
shinyServer(function(input, output) {
  
  # plot the data
  output$phonePlot <- renderPlot({
    
    # Render a barplot
    # barplot for a particular region across different years
    if (input$feature == 'region') {
      barplot(WorldPhones[,input$region], 
            main=input$region,
            ylab="Number of Telephones",
            xlab="Year",
            col = 'blue')
    }

   # barplot for a particular year across different regions
   if (input$feature == 'year') {
      barplot(WorldPhones[input$year,], 
            main=input$year,
            ylab="Number of Telephones",
            xlab="Region",
            col = 'blue')
    }
  
  })
})
